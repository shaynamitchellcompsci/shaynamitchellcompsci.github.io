package com.example.shaynamitchellweighttrackingapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginScreen extends AppCompatActivity {

    EditText usernameInput, passwordInput;
    Button loginButton, createAccountButton;  // Add createAccountButton
    SQLiteDatabase db;
    TextView exclamationText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI elements
        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        loginButton = findViewById(R.id.btnLogin);
        createAccountButton = findViewById(R.id.btnCreateAccount); // Find the create account button
        exclamationText = findViewById(R.id.exclamationText);

        exclamationText.setVisibility(View.INVISIBLE);

        // Initialize the database
        db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Users(username TEXT PRIMARY KEY, password TEXT);");

        // Handle Login Button Click
        loginButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        exclamationText.setVisibility(View.VISIBLE);
                        break;
                    case MotionEvent.ACTION_UP:
                        exclamationText.setVisibility(View.INVISIBLE);
                        v.performClick();
                        handleLogin();
                        break;
                }
                return true;
            }
        });

        // Create Account Button Click
        createAccountButton.setOnClickListener(view -> handleCreateAccount());
    }

    // Function to validate login credentials
    private boolean validateLogin(String username, String password) {
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE username=? AND password=?", new String[]{username, password});
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    // Separate method to handle the login logic (UPDATED)
    private void handleLogin() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        if (validateLogin(username, password)) {
            // Navigate to SMS Screen
            Intent intent = new Intent(LoginScreen.this, SMS.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(LoginScreen.this, "Invalid Login. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    // handle account creation
    private void handleCreateAccount() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
        } else {
            // Check if username exists
            Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE username=?", new String[]{username});
            if (cursor.getCount() > 0) {
                Toast.makeText(this, "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
            } else {
                // Insert new user
                db.execSQL("INSERT INTO Users(username, password) VALUES(?, ?)", new Object[]{username, password});
                Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                // Navigate to SMS Screen
                Intent intent = new Intent(LoginScreen.this, SMS.class);
                startActivity(intent);
                finish();
            }
            cursor.close();
        }
    }
}


















