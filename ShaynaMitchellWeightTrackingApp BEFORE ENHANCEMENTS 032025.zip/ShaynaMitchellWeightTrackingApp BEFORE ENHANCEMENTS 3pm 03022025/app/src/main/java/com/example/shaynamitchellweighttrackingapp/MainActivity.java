package com.example.shaynamitchellweighttrackingapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int SPLASH_SCREEN_DELAY = 4000; // 4 seconds

    EditText usernameInput, passwordInput;
    Button loginButton, createAccountButton;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main); // Splash Screen

        // Delay and transition to login screen after 4 seconds
        new Handler().postDelayed(() -> {
            setContentView(R.layout.activity_login); // Load the login layout after the splash screen

            // Initialize the input fields and buttons
            usernameInput = findViewById(R.id.username);
            passwordInput = findViewById(R.id.password);
            loginButton = findViewById(R.id.btnLogin);
            createAccountButton = findViewById(R.id.btnCreateAccount);

            // Create or open the SQLite database
            db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);

            // Create necessary tables if they don't exist
            db.execSQL("CREATE TABLE IF NOT EXISTS Users(username TEXT PRIMARY KEY, password TEXT);");
            db.execSQL("CREATE TABLE IF NOT EXISTS DailyWeight(weight REAL, unit TEXT, date TEXT);");
            db.execSQL("CREATE TABLE IF NOT EXISTS GoalWeight(goal REAL);"); // add date and unit later

            // Handle login button click
            loginButton.setOnClickListener(view -> {
                String username = usernameInput.getText().toString();
                String password = passwordInput.getText().toString();
                if (validateLogin(username, password)) {
                    // Navigate to the SMS screen after successful login
                    Intent intent = new Intent(MainActivity.this, SMS.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Login.", Toast.LENGTH_SHORT).show();
                }
            });

            // Handle create account button click
            createAccountButton.setOnClickListener(view -> {
                String username = usernameInput.getText().toString();
                String password = passwordInput.getText().toString();
                if (!username.isEmpty() && !password.isEmpty()) {
                    // Insert new user into the Users table
                    db.execSQL("INSERT INTO Users(username, password) VALUES(?, ?)", new Object[]{username, password});
                    Toast.makeText(MainActivity.this, "Account Created.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Username/Password cannot be empty.", Toast.LENGTH_SHORT).show();
                }
            });

        }, SPLASH_SCREEN_DELAY);
    }

    // Method to validate the user's login credentials
    private boolean validateLogin(String username, String password) {
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE username=? AND password=?", new String[]{username, password});
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }
}











/*
package com.example.shaynamitchellweighttrackingapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int SPLASH_SCREEN_DELAY = 4000; // 4 seconds

    EditText usernameInput, passwordInput;
    Button loginButton, createAccountButton;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main); // 4 Second Splash Screen

        // Delay and transition to login screen
        new Handler().postDelayed(() -> {
            setContentView(R.layout.activity_login); // Login Screen
            usernameInput = findViewById(R.id.username);
            passwordInput = findViewById(R.id.password);
            loginButton = findViewById(R.id.btnLogin);
            createAccountButton = findViewById(R.id.btnCreateAccount);

            db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);

            db.execSQL("CREATE TABLE IF NOT EXISTS Users(username TEXT PRIMARY KEY, password TEXT);");
            db.execSQL("CREATE TABLE IF NOT EXISTS DailyWeight(weight REAL, unit TEXT, date TEXT);");
            db.execSQL("CREATE TABLE IF NOT EXISTS GoalWeight(goal REAL, date TEXT);");


            loginButton.setOnClickListener(view -> {
                String username = usernameInput.getText().toString();
                String password = passwordInput.getText().toString();
                if (validateLogin(username, password)) {
                    //When the user clicks the Go! button, they are taken to the SMS screen:
                    Intent intent = new Intent(MainActivity.this, SMS.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Login.", Toast.LENGTH_SHORT).show();
                }
            });

            createAccountButton.setOnClickListener(view -> {
                String username = usernameInput.getText().toString();
                String password = passwordInput.getText().toString();
                if (!username.isEmpty() && !password.isEmpty()) {
                    db.execSQL("INSERT INTO Users(username, password) VALUES(?, ?)", new Object[]{username, password});
                    Toast.makeText(MainActivity.this, "Account Created.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Username/Password cannot be empty.", Toast.LENGTH_SHORT).show();
                }
            });
        }, SPLASH_SCREEN_DELAY);
    }

    private boolean validateLogin(String username, String password) {
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE username=? AND password=?", new String[]{username, password});
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }
}
*/