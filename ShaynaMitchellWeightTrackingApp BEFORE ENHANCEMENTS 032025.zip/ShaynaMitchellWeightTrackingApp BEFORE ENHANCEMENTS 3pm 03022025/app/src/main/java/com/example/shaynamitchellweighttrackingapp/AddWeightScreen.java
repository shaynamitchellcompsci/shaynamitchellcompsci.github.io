package com.example.shaynamitchellweighttrackingapp;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddWeightScreen extends AppCompatActivity {

    private EditText weightField;
    private EditText unitField;
    private EditText goalWeightField;
    private EditText goalUnitField;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        weightField = findViewById(R.id.weight);
        unitField = findViewById(R.id.unit);
        goalWeightField = findViewById(R.id.goalWeight);
        goalUnitField = findViewById(R.id.goalUnit);

        Button submitButton = findViewById(R.id.btnSubmit);
        Button cancelButton = findViewById(R.id.btnCancel);

        // Create or open the database
        db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);

        // Create the necessary tables if they don't already exist

        db.execSQL("CREATE TABLE IF NOT EXISTS DailyWeight (weight TEXT, unit TEXT, date TEXT)");
        //add date back in later if needed:
        db.execSQL("CREATE TABLE IF NOT EXISTS GoalWeight (goal TEXT, unit TEXT)");
        //add date later if needed:
        db.execSQL("CREATE TABLE IF NOT EXISTS LoginInfo (username TEXT, password TEXT)");

        submitButton.setOnClickListener(view -> {
            String weight = weightField.getText().toString().trim();
            String unit = unitField.getText().toString().trim();
            String goalWeight = goalWeightField.getText().toString().trim();
            String goalUnit = goalUnitField.getText().toString().trim();

            if (weight.isEmpty() || unit.isEmpty()) {
                Toast.makeText(this, "Enter weight and unit, please!", Toast.LENGTH_SHORT).show();
                return;
            }

            addWeightToDatabase(weight, unit, goalWeight, goalUnit);
            Toast.makeText(this, "Added weight and goal.", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(AddWeightScreen.this, WeightLogScreen.class);
            startActivity(intent);
            finish();
        });

        cancelButton.setOnClickListener(view -> {
            // Clear any inputs from the current session
            clearInputs();
            Toast.makeText(this, "Current entries cleared.", Toast.LENGTH_SHORT).show();
            // Navigate to the WeightLogScreen
            Intent intent = new Intent(AddWeightScreen.this, WeightLogScreen.class);
            startActivity(intent);
            finish();
        });
    }

    private void addWeightToDatabase(String weight, String unit, String goalWeight, String goalUnit) {
        String date = getCurrentDate();
        // Insert weight and unit into the DailyWeight table
        db.execSQL("INSERT INTO DailyWeight (weight, unit, date) VALUES (?, ?, ?)", new Object[]{weight, unit, date});

        // Insert goal weight and unit into the GoalWeight table if provided
        if (!goalWeight.isEmpty() && !goalUnit.isEmpty()) {
            //add in date here later if needed:
            db.execSQL("INSERT INTO GoalWeight (goal) VALUES (?)", new Object[]{goalWeight});
        }
    }

    private void clearInputs() {
        weightField.setText("");
        unitField.setText("");
        goalWeightField.setText("");
        goalUnitField.setText("");
    }

    private String getCurrentDate() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
        return sdf.format(new java.util.Date());
    }
}












