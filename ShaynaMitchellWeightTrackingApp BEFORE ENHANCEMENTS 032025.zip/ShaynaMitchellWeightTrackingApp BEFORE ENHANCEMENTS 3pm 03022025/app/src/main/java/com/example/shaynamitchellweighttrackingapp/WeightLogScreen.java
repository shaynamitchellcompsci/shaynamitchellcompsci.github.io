package com.example.shaynamitchellweighttrackingapp;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;




public class WeightLogScreen extends AppCompatActivity {
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log); // Link xml

        // Initialize the database
        db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);

        // Retrieve SMS preference (optional)
        SharedPreferences preferences = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        boolean isSmsEnabled = preferences.getBoolean("sms_notifications", false); // Default to false if not found

        // Display a message based on SMS preference
        if (isSmsEnabled) {
            Toast.makeText(this, "SMS Notifications are ON", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS Notifications are OFF", Toast.LENGTH_SHORT).show();
        }

        // Button to navigate to the Add Weight Screen
        Button addWeightButton = findViewById(R.id.addWeightButton);
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightLogScreen.this, AddWeightScreen.class);
            startActivity(intent);
        });


        // Populate the weight log grid
        populateGrid();
    }

    private void populateGrid() {
        GridLayout weightLogGrid = findViewById(R.id.weightLogGrid);

        // Clear any previous data from the grid
        weightLogGrid.removeAllViews();

        // Query and display the daily weight data in the first column
        Cursor weightCursor = db.rawQuery("SELECT weight, unit, date FROM DailyWeight", null);
        if (weightCursor.moveToFirst()) {
            do {
                String weight = weightCursor.getString(0);
                String unit = weightCursor.getString(1);
                String date = weightCursor.getString(2);

                TextView weightEntry = new TextView(this);
                //previous version -weightEntry.setText(weight + " " + unit + " " + date);
                weightEntry.setText(getString(R.string.weight_entry, weight, unit, date));
                weightLogGrid.addView(weightEntry);
            } while (weightCursor.moveToNext());
        }
//add this line
        weightCursor.close();

        // Query and display the login data in the second column
        //add in date later if needed
        Cursor loginCursor = db.rawQuery("SELECT username, password FROM Users", null);
        if (loginCursor.moveToFirst()) {
            do {
                String username = loginCursor.getString(0);
                String password = loginCursor.getString(1);
                //this can be used later if adding date to second column:
                //String loginDate = loginCursor.getString(2);

                TextView loginEntry = new TextView(this);
                //previous version -loginEntry.setText(username + " " + password + " " + loginDate);
                loginEntry.setText(getString(R.string.login_entry, username, password));
                weightLogGrid.addView(loginEntry);
            } while (loginCursor.moveToNext());
        }

        //addline
        loginCursor.close();

        // Query and display the goal weight data in the third column
        //can add date back in here later if needed:
        Cursor goalWeightCursor = db.rawQuery("SELECT goal FROM GoalWeight", null);
        if (goalWeightCursor.moveToFirst()) {
            do {
                String goalWeight = goalWeightCursor.getString(0);
                //String goalUnit = goalWeightCursor.getString(1);
                //can add date back in later:
                //String goalDate = goalWeightCursor.getString(2);
                TextView goalEntry = new TextView(this);
                //previous -goalEntry.setText(goalWeight + " " + goalUnit + " " + goalDate);
                //add date back in here in needed:
                goalEntry.setText(getString(R.string.goal_log_entry, goalWeight));
                weightLogGrid.addView(goalEntry);
            } while (goalWeightCursor.moveToNext());
        }

        goalWeightCursor.close();

        //originally closed all three together at bottom.

    }
}














