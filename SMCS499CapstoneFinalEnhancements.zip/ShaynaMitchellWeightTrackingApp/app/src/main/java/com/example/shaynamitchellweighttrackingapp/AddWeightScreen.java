package com.example.shaynamitchellweighttrackingapp;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddWeightScreen extends AppCompatActivity {

    private EditText weightField;
    private EditText unitField;
    private EditText goalWeightField;
    private EditText goalUnitField;
    private SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        weightField = findViewById(R.id.weight);
        unitField = findViewById(R.id.unit);
        goalWeightField = findViewById(R.id.goalWeight);
        goalUnitField = findViewById(R.id.goalUnit);

        Button submitButton = findViewById(R.id.btnSubmit);
        Button cancelButton = findViewById(R.id.btnCancel);

        // Open the database or create it if it doesn't exist
        db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);

        // Create the necessary tables if they don't already exist
        db.execSQL("CREATE TABLE IF NOT EXISTS DailyWeight (weight TEXT, unit TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS GoalWeight (goal TEXT, unit TEXT DEFAULT '')");

        // Check if the 'unit' column exists in GoalWeight, add it if missing
        if (!doesColumnExist(db, "GoalWeight", "unit")) {
            db.execSQL("ALTER TABLE GoalWeight ADD COLUMN unit TEXT");
        }

        submitButton.setOnClickListener(view -> {
            String weight = weightField.getText().toString().trim();
            String unit = unitField.getText().toString().trim();
            String goalWeight = goalWeightField.getText().toString().trim();
            String goalUnit = goalUnitField.getText().toString().trim();

            boolean isValid = true;

            // Validate Weight (Required & Must Be a Number)
            if (weight.isEmpty()) {
                weightField.setError("Weight is required!");
                isValid = false;
            } else {
                try {
                    Double.parseDouble(weight);
                } catch (NumberFormatException e) {
                    weightField.setError("Enter a valid number!");
                    isValid = false;
                }
            }

            // Validate Unit (Required)
            if (unit.isEmpty()) {
                unitField.setError("Unit is required!");
                isValid = false;
            }

            // Goal Weight is OPTIONAL but should be a number if provided
            if (!goalWeight.isEmpty()) {
                try {
                    Double.parseDouble(goalWeight);
                } catch (NumberFormatException e) {
                    goalWeightField.setError("Enter a valid number!");
                    isValid = false;
                }
            }

            // Goal Unit is OPTIONAL (No validation needed)

            // Stop submission if validation fails
            if (!isValid) return;

            //If all checks pass, insert into the database
            addWeightToDatabase(weight, unit, goalWeight, goalUnit);
            Toast.makeText(this, "Added weight and goal.", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(AddWeightScreen.this, WeightLogScreen.class);
            startActivity(intent);
            finish();
        });

        cancelButton.setOnClickListener(view -> {
            // Clear any inputs from the current session
            clearInputs();
            Toast.makeText(this, "Current entries cleared.", Toast.LENGTH_SHORT).show();

            // Navigate to WeightLogScreen
            Intent intent = new Intent(AddWeightScreen.this, WeightLogScreen.class);
            startActivity(intent);
            finish();
        });
    }

    private void addWeightToDatabase(String weight, String unit, String goalWeight, String goalUnit) {
        // Store weight and unit in DailyWeight table
        db.execSQL("INSERT INTO DailyWeight (weight, unit) VALUES (?, ?)",
                new Object[]{weight, unit});

        // Store goal weight and goal unit in GoalWeight table (ONLY if both are provided)
        if (!goalWeight.isEmpty() && !goalUnit.isEmpty()) {
            db.execSQL("INSERT INTO GoalWeight (goal, unit) VALUES (?, ?)",
                    new String[]{goalWeight.isEmpty() ? "0" : goalWeight, goalUnit.isEmpty() ? "" : goalUnit});

        }
    }

    private void clearInputs() {
        weightField.setText("");
        unitField.setText("");
        goalWeightField.setText("");
        goalUnitField.setText("");
    }


    //see if column exists

    //Function to Check if a column Exists in a Table
    private boolean doesColumnExist(SQLiteDatabase db, String tableName, String columnName) {
        Cursor cursor = db.rawQuery("PRAGMA table_info(" + tableName + ")", null);
        int columnIndex = cursor.getColumnIndex("name");

        if (cursor.moveToFirst()) {
            do {
                String existingColumn = cursor.getString(columnIndex);
                if (existingColumn.equals(columnName)) {
                    cursor.close();
                    return true; //Column already exists
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false; // Column does not exist
    }

    private String getCurrentDate() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
        return sdf.format(new java.util.Date());
    }
}