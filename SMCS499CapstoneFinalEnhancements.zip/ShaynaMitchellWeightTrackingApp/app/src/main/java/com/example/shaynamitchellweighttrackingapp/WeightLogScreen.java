package com.example.shaynamitchellweighttrackingapp;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.util.Log;
import androidx.core.content.ContextCompat;

public class WeightLogScreen extends AppCompatActivity {
    private SQLiteDatabase db;
    private boolean goalUnitExists = false; //check if 'unit' exists in GoalWeight table

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log); // Link XML

        // Initialize the database
        db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);
        if (db == null) {
            Log.e("DB_ERROR", "Database not initialized!");
            return;
        }

        //Check if 'unit' column exists in GoalWeight table
        goalUnitExists = doesColumnExist(db, "GoalWeight", "unit");

        // Debugging: Check if DailyWeight table has data
        Cursor weightCursor = db.rawQuery("SELECT * FROM DailyWeight", null);
        if (weightCursor != null) {
            Log.d("DB_DEBUG", "Total weight entries found: " + weightCursor.getCount());
            weightCursor.close(); // Prevent memory leaks
        } else {
            Log.d("DB_DEBUG", "Weight cursor is null. Table might not exist.");
        }

        // Retrieve SMS preference
        SharedPreferences preferences = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        boolean isSmsEnabled = preferences.getBoolean("sms_notifications", false);

        // Display a message based on SMS preference
        Toast.makeText(this, isSmsEnabled ? "SMS Notifications are ON" : "SMS Notifications are OFF", Toast.LENGTH_SHORT).show();

        // Button to navigate to the Add Weight Screen
        Button addWeightButton = findViewById(R.id.addWeightButton);
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightLogScreen.this, AddWeightScreen.class);
            startActivity(intent);
        });

        // Populate the weight log grid
        populateGrid();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateGrid();  // Refreshes data when returning to this screen
    }

    private void populateGrid() {
        GridLayout weightLogGrid = findViewById(R.id.weightLogGrid);

        // Ensure the GridLayout exists in XML
        if (weightLogGrid == null) {
            Log.e("UI_ERROR", "GridLayout weightLogGrid not found in XML.");
            return;
        }

        // Clear any previous data from the grid
        weightLogGrid.removeAllViews();

        //Query and display the daily weight data
        Cursor weightCursor = db.rawQuery("SELECT weight, unit FROM DailyWeight", null);
        if (weightCursor != null && weightCursor.moveToFirst()) {
            do {
                String weight = weightCursor.getString(0);
                String unit = weightCursor.getString(1);

                TextView weightEntry = new TextView(this);
                weightEntry.setText(weight + " " + unit);
                weightEntry.setTextColor(getResources().getColor(android.R.color.white));
                weightLogGrid.addView(weightEntry);
            } while (weightCursor.moveToNext());
            weightCursor.close();
        } else {
            Log.d("DB_DEBUG", "No weight entries found.");
        }

        //Query and display the login data
        Cursor loginCursor = db.rawQuery("SELECT username, password FROM Users", null);
        if (loginCursor != null && loginCursor.moveToFirst()) {
            do {
                String username = loginCursor.getString(0);
                String password = loginCursor.getString(1);

                TextView loginEntry = new TextView(this);
                loginEntry.setText(getString(R.string.login_entry, username, password));
                loginEntry.setTextColor(ContextCompat.getColor(this, android.R.color.white));
                weightLogGrid.addView(loginEntry);
            } while (loginCursor.moveToNext());
            loginCursor.close();
        }

        //Query and display the goal weight data safely
        String goalWeightQuery = goalUnitExists ?
                "SELECT goal, unit FROM GoalWeight" :  // If unit column exists
                "SELECT goal FROM GoalWeight";         // If unit column doesn't exist

        Cursor goalWeightCursor = db.rawQuery(goalWeightQuery, null);
        if (goalWeightCursor != null && goalWeightCursor.moveToFirst()) {
            do {
                String goalWeight = goalWeightCursor.getString(0) != null ? goalWeightCursor.getString(0) : "";
                String goalUnit = goalUnitExists && goalWeightCursor.getColumnCount() > 1
                        ? goalWeightCursor.getString(1) != null ? goalWeightCursor.getString(1) : ""
                        : "";

                TextView goalEntry = new TextView(this);
                goalEntry.setText(goalWeight + (goalUnit.isEmpty() ? "" : " " + goalUnit));
                goalEntry.setTextColor(getResources().getColor(android.R.color.white));
                weightLogGrid.addView(goalEntry);
            } while (goalWeightCursor.moveToNext());
            goalWeightCursor.close();
        }
    }

    //Helper Function to Check if a Column Exists
    private boolean doesColumnExist(SQLiteDatabase db, String tableName, String columnName) {
        Cursor cursor = db.rawQuery("PRAGMA table_info(" + tableName + ")", null);
        int columnIndex = cursor.getColumnIndex("name");

        if (cursor.moveToFirst()) {
            do {
                String existingColumn = cursor.getString(columnIndex);
                if (existingColumn.equals(columnName)) {
                    cursor.close();
                    return true; //Column exists
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false; //Column does not exist
    }
}





/*
package com.example.shaynamitchellweighttrackingapp; //Weight will crash without this line

// All imports are needed for the app to run correctly and for all classes to communicate
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.util.Log;
import androidx.core.content.ContextCompat;


// WeightLogScreen class
public class WeightLogScreen extends AppCompatActivity {
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log); // Link XML

        // Initialize the database
        db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);
        if (db == null) {
            Log.e("DB_ERROR", "Database not initialized!");
            return;
        }

        // Debugging: Check if DailyWeight table has data
        Cursor weightCursor = db.rawQuery("SELECT * FROM DailyWeight", null);
        if (weightCursor != null) {
            Log.d("DB_DEBUG", "Total weight entries found: " + weightCursor.getCount());
            weightCursor.close(); // Prevent memory leaks
        } else {
            Log.d("DB_DEBUG", "Weight cursor is null. Table might not exist.");
        }

        // Retrieve SMS preference
        SharedPreferences preferences = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        boolean isSmsEnabled = preferences.getBoolean("sms_notifications", false);

        // Display a message based on SMS preference
        Toast.makeText(this, isSmsEnabled ? "SMS Notifications are ON" : "SMS Notifications are OFF", Toast.LENGTH_SHORT).show();

        // Button to navigate to the Add Weight Screen
        Button addWeightButton = findViewById(R.id.addWeightButton);
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightLogScreen.this, AddWeightScreen.class);
            startActivity(intent);
        });

        // Populate the weight log grid
        populateGrid();
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateGrid();  // Refreshes data when returning to this screen
    }


    private void populateGrid() {
        GridLayout weightLogGrid = findViewById(R.id.weightLogGrid);

        // Ensure the GridLayout exists in XML
        if (weightLogGrid == null) {
            Log.e("UI_ERROR", "GridLayout weightLogGrid not found in XML.");
            return;
        }

        // Clear any previous data from the grid
        weightLogGrid.removeAllViews();

        // Query and display the daily weight data in the first column (without date)
        Cursor weightCursor = db.rawQuery("SELECT weight, unit FROM DailyWeight", null);
        if (weightCursor != null && weightCursor.moveToFirst()) {
            do {
                String weight = weightCursor.getString(0);
                String unit = weightCursor.getString(1);

                TextView weightEntry = new TextView(this);
                weightEntry.setText(weight + " " + unit);  // Example: "150 lbs"
                weightEntry.setTextColor(getResources().getColor(android.R.color.white));
                weightLogGrid.addView(weightEntry);
            } while (weightCursor.moveToNext());
            weightCursor.close();
        } else {
            Log.d("DB_DEBUG", "No weight entries found.");
        }

        // Query and display the login data in the second column (username & password only)
        Cursor loginCursor = db.rawQuery("SELECT username, password FROM Users", null);
        if (loginCursor != null && loginCursor.moveToFirst()) {
            do {
                String username = loginCursor.getString(0);
                String password = loginCursor.getString(1);

                TextView loginEntry = new TextView(this);
                loginEntry.setText(getString(R.string.login_entry, username, password));
                loginEntry.setTextColor(ContextCompat.getColor(this, android.R.color.white)); //white text on weight log screen
                weightLogGrid.addView(loginEntry);
            } while (loginCursor.moveToNext());
            loginCursor.close();
        }


        // Query and display the goal weight data in the third column (goal weight only)
        Cursor goalWeightCursor = db.rawQuery("SELECT goal, unit FROM GoalWeight", null);
        if (goalWeightCursor != null && goalWeightCursor.moveToFirst()) {
            do {
                String goalWeight = goalWeightCursor.getString(0);
                String goalUnit = goalWeightCursor.getString(1);

                TextView goalEntry = new TextView(this);
                goalEntry.setText(goalWeight + " " + goalUnit);  // Example: "120 lbs"
                goalEntry.setTextColor(getResources().getColor(android.R.color.white));
                weightLogGrid.addView(goalEntry);
            } while (goalWeightCursor.moveToNext());
            goalWeightCursor.close();
        }
    }
}




*/



















/*

package com.example.shaynamitchellweighttrackingapp; //Weight will crash without this line


//All imports are needed for app to run correctly and for all classes to communicate to each other
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.util.Log;


//WeightLogScreen class
public class WeightLogScreen extends AppCompatActivity {
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_log); // Link xml


        // Initialize the database
        db = openOrCreateDatabase("WeightTrackingDB", MODE_PRIVATE, null);


        //debug the grid display:
        Log.d("DB_DEBUG", "Fetching weight data...");
        Cursor weightCursor = db.rawQuery("SELECT weight, unit, date FROM DailyWeight", null);
        Log.d("DB_DEBUG", "Weight entries found: " + weightCursor.getCount());

        //debug if no data found:
        if (weightCursor.getCount() == 0) {
            Toast.makeText(this, "No weight entries found.", Toast.LENGTH_SHORT).show();
        }

        // Retrieve SMS preference (optional)
        SharedPreferences preferences = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        boolean isSmsEnabled = preferences.getBoolean("sms_notifications", false); // Default to false if not found

        // Display a message based on SMS preference
        if (isSmsEnabled) {
            Toast.makeText(this, "SMS Notifications are ON", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS Notifications are OFF", Toast.LENGTH_SHORT).show();
        }

        // Button to navigate to the Add Weight Screen
        Button addWeightButton = findViewById(R.id.addWeightButton);
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(WeightLogScreen.this, AddWeightScreen.class);
            startActivity(intent);
        });


        // Populate the weight log grid
        populateGrid();
    }

    private void populateGrid() {
        GridLayout weightLogGrid = findViewById(R.id.weightLogGrid);

        // Ensure the GridLayout exists in XML
        if (weightLogGrid == null) {
            Log.e("UI_ERROR", "GridLayout weightLogGrid not found in XML.");
            return;
        }

        // Clear any previous data from the grid
        weightLogGrid.removeAllViews();

        // Query and display the daily weight data in the first column (without date)
        Cursor weightCursor = db.rawQuery("SELECT weight, unit FROM DailyWeight", null);
        if (weightCursor.moveToFirst()) {
            do {
                String weight = weightCursor.getString(0);
                String unit = weightCursor.getString(1);

                TextView weightEntry = new TextView(this);
                weightEntry.setText(getString(R.string.weight_entry, weight, unit));
                weightLogGrid.addView(weightEntry);
            } while (weightCursor.moveToNext());
        }
        weightCursor.close(); // Close cursor to avoid memory leaks

        // Query and display the login data in the second column (username & password only)
        Cursor loginCursor = db.rawQuery("SELECT username, password FROM Users", null);
        if (loginCursor.moveToFirst()) {
            do {
                String username = loginCursor.getString(0);
                String password = loginCursor.getString(1);

                TextView loginEntry = new TextView(this);
                loginEntry.setText(getString(R.string.login_entry, username, password));
                weightLogGrid.addView(loginEntry);
            } while (loginCursor.moveToNext());
        }
        loginCursor.close();

        // Query and display the goal weight data in the third column (goal weight only)
        Cursor goalWeightCursor = db.rawQuery("SELECT goal FROM GoalWeight", null);
        if (goalWeightCursor.moveToFirst()) {
            do {
                String goalWeight = goalWeightCursor.getString(0);

                TextView goalEntry = new TextView(this);
                goalEntry.setText(getString(R.string.goal_log_entry, goalWeight));
                weightLogGrid.addView(goalEntry);
            } while (goalWeightCursor.moveToNext());
        }
        goalWeightCursor.close();
    }


    //old populate grid function
 /*   private void populateGrid() {
        GridLayout weightLogGrid = findViewById(R.id.weightLogGrid);

        // Clear any previous data from the grid
        weightLogGrid.removeAllViews();

        // Query and display the daily weight data in the first column
        Cursor weightCursor = db.rawQuery("SELECT weight, unit, date FROM DailyWeight", null);
        if (weightCursor.moveToFirst()) {
            do {
                String weight = weightCursor.getString(0);
                String unit = weightCursor.getString(1);
                String date = weightCursor.getString(2);

                TextView weightEntry = new TextView(this);
                //previous version -weightEntry.setText(weight + " " + unit + " " + date);
                weightEntry.setText(getString(R.string.weight_entry, weight, unit, date));
                weightLogGrid.addView(weightEntry);
            } while (weightCursor.moveToNext());
        }
//add this line
        weightCursor.close();
*/
/*

        // Query and display the login data in the second column
        //add in date later if needed
        Cursor loginCursor = db.rawQuery("SELECT username, password FROM Users", null);
        if (loginCursor.moveToFirst()) {
            do {
                String username = loginCursor.getString(0);
                String password = loginCursor.getString(1);
                //this can be used later if adding date to second column:
                //String loginDate = loginCursor.getString(2);

                TextView loginEntry = new TextView(this);
                //previous version -loginEntry.setText(username + " " + password + " " + loginDate);
                loginEntry.setText(getString(R.string.login_entry, username, password));
                weightLogGrid.addView(loginEntry);
            } while (loginCursor.moveToNext());
        }

        //addline
        loginCursor.close();

        // Query and display the goal weight data in the third column
        //can add date back in here later if needed:
        Cursor goalWeightCursor = db.rawQuery("SELECT goal FROM GoalWeight", null);
        if (goalWeightCursor.moveToFirst()) {
            do {
                String goalWeight = goalWeightCursor.getString(0);
                //String goalUnit = goalWeightCursor.getString(1);
                //can add date back in later:
                //String goalDate = goalWeightCursor.getString(2);
                TextView goalEntry = new TextView(this);
                //previous -goalEntry.setText(goalWeight + " " + goalUnit + " " + goalDate);
                //add date back in here in needed:
                goalEntry.setText(getString(R.string.goal_log_entry, goalWeight));
                weightLogGrid.addView(goalEntry);
            } while (goalWeightCursor.moveToNext());
        }

        goalWeightCursor.close();

        //originally closed all three together at bottom.

    }
}


*/









